from django.urls import path,re_path
from . import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.views.static import serve
from homeapp.views import *

urlpatterns = [

    #Admin Logout Page
    re_path( r'^Admin_logout/$', views.Admin_logout, name='Admin_logout'),

    #Add Branch Page
    re_path( r'^branch/$', views.admin_branch, name='admin_branch'),

    #Add department Page
    re_path( r'^department/$', views.admin_department, name='admin_department'),

    #Add designation Page
    re_path( r'^designation/$', views.admin_designation, name='admin_designation'),

    #Display Dashboard Page
    re_path(r'^$', views.admin_dashboard, name='admin_dashboard'),

    #Add Document, list Document Page
    re_path(r'^admin_view_list/$', views.admin_view_list, name='admin_view_list'),

    #View Document Page
    re_path( r'^admin_view_pdf/(?P<id>\d+)$', views.admin_view_pdf, name='admin_view_pdf'),

    #Add Document Page
    re_path( r'^admin_document/(?P<id>\d+)$', views.admin_document, name='admin_document'),
    
    #Select items depend on category Ajax
    re_path( r'^get-items-by-category$', views.get_items_by_category, name='get_items_by_category'),

    #Add Customer
    re_path( r'^admin_ajax_add_customer/$', views.admin_ajax_add_customer, name='admin_ajax_add_customer'),

    #Edit Customer
    re_path( r'^admin_edit_customer/(?P<id>\d+)$', views.admin_edit_customer, name='admin_edit_customer'),

    #Delete Customer
    re_path( r'^admin_delete_customer/(?P<id>\d+)$', views.admin_delete_customer, name='admin_delete_customer'),

    #Add Category
    re_path( r'^admin_add_category/$', views.admin_add_category, name='admin_add_category'),

    #Edit Category
    re_path( r'^admin_edit_category/(?P<id>\d+)$', views.admin_edit_category, name='admin_edit_category'),
    
    #Delete Category
    re_path( r'^admin_delete_category/(?P<id>\d+)$', views.admin_delete_category, name='admin_delete_category'),

    #Add Decor Items
    re_path( r'^admin_ajax_add_quotation/$', views.admin_ajax_add_quotation, name='admin_ajax_add_quotation'),
    
    #Edit Items
    re_path( r'^admin_edit_items/(?P<id>\d+)$', views.admin_edit_items, name='admin_edit_items'),
    
    #Delete Items
    re_path( r'^admin_delete_items/(?P<id>\d+)$', views.admin_delete_items, name='admin_delete_items'),

    #Add Decor Sub Items
    re_path( r'^admin_ajax_add_subitem/$', views.admin_ajax_add_subitem, name='admin_ajax_add_subitem'),
    
    #Edit Sub Items
    re_path( r'^admin_edit_subitems/(?P<id>\d+)$', views.admin_edit_subitems, name='admin_edit_subitems'),
    
    #Delete Items
    re_path( r'^admin_delete_subitems/(?P<id>\d+)$', views.admin_delete_subitems, name='admin_delete_subitems'),

    #Gallery
    re_path( r'^admin_add_gallery/(?P<id>\d+)$', views.admin_add_gallery, name='admin_add_gallery'),

    #Add Gallery
    re_path( r'^admin_ajax_add_gallery_save/$', views.admin_ajax_add_gallery_save, name='admin_ajax_add_gallery_save'),
    
    #Edit Gallery
    re_path( r'^admin_edit_gallery/(?P<id>\d+)$', views.admin_edit_gallery, name='admin_edit_gallery'),
    
    #Delete Gallery
    re_path( r'^admin_ajax_delete_gallery/$',views.admin_ajax_delete_gallery,name='admin_ajax_delete_gallery'),
    
    
    
    re_path(r'^static/(?P<path>.*)$', serve,{'document_root': settings.STATIC_ROOT}),
]
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
