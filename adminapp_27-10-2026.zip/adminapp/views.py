from django.shortcuts import render,redirect
from .models import *;
from django.conf import settings
from django.http import HttpResponse,JsonResponse
from django.template.loader import get_template
from xhtml2pdf import pisa
import os
import random
from django. contrib import messages
from datetime import datetime,date, timedelta
from django.http import HttpResponse, HttpResponseRedirect
from django.db.models import Q
from io import BytesIO
from django.core.files import File
from django.core.mail import send_mail
from django.core.files.storage import FileSystemStorage
from django.db.models import Sum
from homeapp.models import *
from .views import *
from homeapp.views import *
from PIL import Image, ImageDraw
from io import BytesIO
import base64
from django.http import JsonResponse
from django.views.decorators.http import require_POST





#Admin Logout Page
def Admin_logout(request):
    if 'A_id' in request.session:  
        request.session.flush()
        return redirect("/")
    else:
        return redirect('/') 

#Add Branch Page
def admin_index(request):
    return render(request,'admin/admin_index.html')

#Add Branch Page
def admin_branch(request):
    return render(request,'home/branch.html')

#Add Department Page
def admin_department(request):
    return render(request,'home/department.html')

#Add Designation Page
def admin_designation(request):
    return render(request,'home/designation.html')

#Display Dashboard Page
def admin_dashboard(request):
    if 'A_id' in request.session:
        if request.session.has_key('A_id'):
            A_id = request.session['A_id']
        else:
            return redirect('/')
        
        Adm=login_register.objects.get(id= A_id)
        return render(request,'admin/admin_dashboard.html',{'Adm':Adm})
    else:
        return redirect('/')

#Add Document, list Document Page
def admin_view_list(request):
    if 'A_id' in request.session:
        if request.session.has_key('A_id'):
            A_id = request.session['A_id']
        else:
            return redirect('/')
        Adm=login_register.objects.get(id= A_id)
        view_customer = admin_Customer.objects.filter(admin_id=A_id)
        return render(request,'admin/admin_view_list.html',{'cust':view_customer,'Adm':Adm})
    else:
        return redirect('/')

#Helper function for image curved radius
def rounded_image(image_path, radius=30):
    image = Image.open(image_path).convert("RGBA")

    mask = Image.new("L", image.size, 0)
    draw = ImageDraw.Draw(mask)

    draw.rounded_rectangle(
        (0, 0, image.width, image.height),
        radius=radius,
        fill=255
    )

    rounded = Image.new("RGBA", image.size, (255, 255, 255, 0))
    rounded.paste(image, (0, 0), mask)

    output = BytesIO()
    rounded.save(output, format="PNG")

    encoded = base64.b64encode(output.getvalue()).decode("utf-8")

    return f"data:image/png;base64,{encoded}"

#View Document Page
def admin_view_pdf(request,id):
    if 'A_id' in request.session:
        if request.session.has_key('A_id'):
            A_id = request.session['A_id']
        else:
            return redirect('/')

        Adm=login_register.objects.get(id= A_id)
        cus = admin_Customer.objects.get(id=id)
        cat = admin_Category.objects.filter(admin_id=A_id,admin_decor_items__customer_id=id).distinct()
        mitem = admin_decor_items.objects.filter(customer_id=id).select_related('item_category').order_by('item_category_id')
        sitem = admin_decor_subitems.objects.filter(customer_id=id)
        gall = admin_gallery.objects.filter(customer_id=id)
    
        for e in gall:
            e.rounded_img = rounded_image(
                e.gallery_img.path,
                radius=80
            )
        
        template_path = 'admin/admin_view_pdf.html'
        context = {
        "background": os.path.join(settings.MEDIA_ROOT, "background4.jpg"),
        "background1": os.path.join(settings.MEDIA_ROOT, "background1.jpg"),
        "background2": os.path.join(settings.MEDIA_ROOT, "background2.jpg"),
        'media_url':settings.MEDIA_URL,
        'cus': cus,
        'mitem': mitem,
        'sitem': sitem,
        'cat': cat,
        'gall': gall,
        'Adm':Adm
        }
        # Create a Django response object, and specify content_type as pdf
        response = HttpResponse(content_type='application/pdf')
        #response['Content-Disposition'] = 'attachment; filename="certificate.pdf"'
        response['Content-Disposition'] = 'filename="file.pdf"'
        # find the template and render it.
        template = get_template(template_path)
        html = template.render(context)

        # create a pdf
        pisa_status = pisa.CreatePDF(
        html, dest=response)
        


        # if error then show some funy view
        if pisa_status.err:
            return HttpResponse('We had some errors <pre>' + html + '</pre>')
        return response
    else:
        return redirect('/')

#Select items depend on category Ajax
def get_items_by_category(request):

    category_id = request.GET.get('category_id')

    items = admin_decor_items.objects.filter(
        item_category_id=category_id
    ).values(
        'id',
        'item_name'
    )

    return JsonResponse({
        'items': list(items)
    })

#Add Document Page
def admin_document(request,id):
    if 'A_id' in request.session:
        if request.session.has_key('A_id'):
            A_id = request.session['A_id']
        else:
            return redirect('/')
        Adm=login_register.objects.get(id= A_id)
        view_customer = admin_Customer.objects.get(id=id)
        item = admin_decor_items.objects.filter(customer_id=id)
        sitem = admin_decor_subitems.objects.filter(customer_id=id)
        cat = admin_Category.objects.filter(admin_id=A_id)
        custid = admin_decor_items.objects.filter(customer_id=id)
        return render(request,'admin/admin_document.html',{'Adm':Adm,'cust':view_customer,'custid':custid,'item':item,'cat':cat,'sitem':sitem})
    else:
        return redirect('/')

#Add customer
def admin_ajax_add_customer(request):
    if 'A_id' in request.session:
        if request.session.has_key('A_id'):
            A_id = request.session['A_id']
        else:
            return redirect('/')
        
        desig = login_register.objects.get(id=A_id)

        if request.method=='POST':
            Add_cust = admin_Customer()
            Add_cust.customer_name = request.POST.get('custname')
            Add_cust.customer_address = request.POST.get('custaddress')
            Add_cust.customer_venue = request.POST.get('custvenue')
            Add_cust.customer_date = request.POST.get('custdate')
            Add_cust.customer_theme = request.POST.get('custtheme')
            Add_cust.customer_function_type = request.POST.get('custfunction')
            Add_cust.customer_contact = request.POST.get('custcontact')
            Add_cust.customer_advance = request.POST.get('custadvance')
            Add_cust.admin_id = A_id
            Add_cust.save()
            return redirect('admin_view_document')
        else:
            return JsonResponse({'success': False, 'message': 'Invalid request method'})
    else:
            return redirect('/')

#Edit category
def admin_edit_customer(request,id):
    if 'A_id' in request.session:
        if request.session.has_key('A_id'):
            A_id = request.session['A_id']
        else:
            return redirect('/')
        Adm=login_register.objects.get(id= A_id)
        desig = login_register.objects.get(id=A_id)
        get_cust = admin_Customer.objects.get(id=id)
        if request.method=='POST':
            edit_cust = admin_Customer.objects.get(id=id)
            edit_cust.category = request.POST.get('edit_cat_name')
            edit_cust.customer_name = request.POST.get('custname')
            edit_cust.customer_address = request.POST.get('custaddress')
            edit_cust.customer_venue = request.POST.get('custvenue')
            edit_cust.customer_date = request.POST.get('custdate')
            edit_cust.customer_theme = request.POST.get('custtheme')
            edit_cust.customer_function_type = request.POST.get('custfunction')
            edit_cust.customer_contact = request.POST.get('custcontact')
            edit_cust.customer_advance = request.POST.get('custadvance')
            edit_cust.admin_id = A_id
            edit_cust.save()
            return redirect('admin_view_list')
        return render(request,'admin/admin_edit_customer.html',{'get_cust':get_cust,'Adm':Adm})
    else:
            return redirect('/')

#Delete Customer
def admin_delete_customer(request,id):
    cust = admin_Customer.objects.get(id=id)
    cust.delete()
    return redirect('admin_view_list')

#Add category
def admin_add_category(request):
    if 'A_id' in request.session:
        if request.session.has_key('A_id'):
            A_id = request.session['A_id']
        else:
            return redirect('/')
        Adm=login_register.objects.get(id= A_id)
        
        desig = login_register.objects.get(id=A_id)
        cate = admin_Category.objects.filter(admin_id=A_id)
        
        if request.method=='POST':
            Add_cat = admin_Category()
            Add_cat.category = request.POST.get('cat_name')
            Add_cat.admin_id = A_id
            Add_cat.save()
        return render(request,'admin/admin_add_category.html',{'cate':cate,'Adm':Adm})
    else:
            return redirect('/')

#Edit category
def admin_edit_category(request,id):
    if 'A_id' in request.session:
        if request.session.has_key('A_id'):
            A_id = request.session['A_id']
        else:
            return redirect('/')
        Adm=login_register.objects.get(id= A_id)
        desig = login_register.objects.get(id=A_id)
        get_cate = admin_Category.objects.get(id=id)
        if request.method=='POST':
            edit_cat = admin_Category.objects.get(id=id)
            edit_cat.category = request.POST.get('edit_cat_name')
            edit_cat.admin_id = A_id
            edit_cat.save()
            return redirect('admin_add_category')
        return render(request,'admin/admin_edit_category.html',{'get_cate':get_cate,'Adm':Adm})
    else:
            return redirect('/')

#Delete category
def admin_delete_category(request,id):
    cat = admin_Category.objects.get(id=id)
    cat.delete()
    return redirect('admin_add_category')

#Add Decor Items Ajax
def admin_ajax_add_quotation(request):
    if 'A_id' in request.session:
        if request.session.has_key('A_id'):
            A_id = request.session['A_id']
        else:
            return redirect('/')
        
        desig = login_register.objects.get(id=A_id)
        
        if request.method=='POST':
            Add_items = admin_decor_items()
            Add_items.item_category_id = request.POST.get('mcat')
            Add_items.item_name = request.POST.get('item')
            item_qty = request.POST.get('qty')
            item_price = request.POST.get('price')
            Add_items.customer_id = request.POST.get('cid')
            advance = request.POST.get('cadv')
            Add_items.branch_id = desig.branch.id
            Add_items.department_id = desig.department.id
            Add_items.designation_id = desig.designation.id
            Add_items.admin_id = A_id
            
            if not item_qty:
                Add_items.item_qty = 1
                Add_items.item_qty_status = 'nill'
            else:
                Add_items.item_qty = int(item_qty)
                Add_items.item_qty_status = 'data'

            if not item_price:
                Add_items.item_price = 1
                Add_items.item_price_status = 'nill'
            else:
                Add_items.item_price = int(item_price)
                Add_items.item_price_status = 'data'

            if Add_items.item_price_status == 'data' and Add_items.item_qty_status == 'data':
                Add_items.item_total = int(Add_items.item_qty) * int(Add_items.item_price)
            elif Add_items.item_price_status == 'data' and Add_items.item_qty_status == 'nill':
                Add_items.item_total = 1 * int(Add_items.item_price)
            elif Add_items.item_price_status == 'nill' and Add_items.item_qty_status == 'data':
                Add_items.item_total = 0
            elif Add_items.item_price_status == 'nill' and Add_items.item_qty_status == 'nill':
                Add_items.item_total = 0
            else:
                return
                
            
            total = admin_decor_items.objects.filter(
                customer_id=Add_items.customer_id
            )
            stotal = admin_decor_subitems.objects.filter(
                customer_id=Add_items.customer_id
            )
            n=0
            for i in total:
                n+=int(i.item_total or 0)
            s=Add_items.item_total+n 
            p=0
            for q in stotal:
                p+=int(q.sitem_total or 0) 
             
            kk=s+p
            Add_items.item_final_amount = s
            Add_items.item_payable_amount = s - int(advance)
            # Add_items.item_final_amount = a - int(advance)



            Add_items.save()

            Add_items1 = admin_Customer.objects.get(id=Add_items.customer_id)
            Add_items1.customer_payable_amt = kk - int(advance)
            Add_items1.customer_total_amt = kk
            Add_items1.save()
            return render(request,'admin/admin_document.html')
        else:
            return JsonResponse({'success': False, 'message': 'Invalid request method'})
    else:
            return redirect('/')

#Edit Decor Items
def admin_edit_items(request,id):
    if 'A_id' in request.session:
        if request.session.has_key('A_id'):
            A_id = request.session['A_id']
        else:
            return redirect('/')
        Adm=login_register.objects.get(id= A_id)
        desig = login_register.objects.get(id=A_id)
        view_customer = admin_Customer.objects.filter(admin_id=A_id)
        cat = admin_Category.objects.filter(admin_id=A_id)
        get_items = admin_decor_items.objects.get(id=id)
        if request.method=='POST':
            edit_items = admin_decor_items.objects.get(id=id)
            edit_items.item_category_id = request.POST.get('mcat')
            edit_items.item_name = request.POST.get('item')
            item_qty = request.POST.get('qty')
            item_price = request.POST.get('price')
            advance = request.POST.get('cadv')

            if not item_qty:
                edit_items.item_qty = 1
                edit_items.item_qty_status = 'nill'
            else:
                edit_items.item_qty = int(item_qty)
                edit_items.item_qty_status = 'data'

            if not item_price:
                edit_items.item_price = 1
                edit_items.item_price_status = 'nill'
            else:
                edit_items.item_price = int(item_price)
                edit_items.item_price_status = 'data'

            if edit_items.item_price_status == 'data' and edit_items.item_qty_status == 'data':
                edit_items.item_total = int(edit_items.item_qty) * int(edit_items.item_price)
            elif edit_items.item_price_status == 'data' and edit_items.item_qty_status == 'nill':
                edit_items.item_total = 1 * int(edit_items.item_price)
            elif edit_items.item_price_status == 'nill' and edit_items.item_qty_status == 'data':
                edit_items.item_total = 0
            elif edit_items.item_price_status == 'nill' and edit_items.item_qty_status == 'nill':
                edit_items.item_total = 0
            else:
                return

            total = admin_decor_items.objects.filter(
                customer_id=edit_items.customer_id
            )
            stotal = admin_decor_subitems.objects.filter(
                customer_id=edit_items.customer_id
            )
            n=0
            for i in total:
                n+=int(i.item_total or 0)
            s=edit_items.item_total+n 
            p=0
            for q in stotal:
                p+=int(q.sitem_total or 0) 
             
            kk=s+p
            edit_items.item_final_amount = s
            edit_items.item_payable_amount = s - int(advance)
            # Add_items.item_final_amount = a - int(advance)



            edit_items.save()

            edit_items1 = admin_Customer.objects.get(id=edit_items.customer_id)
            edit_items1.customer_payable_amt = kk - int(advance)
            edit_items1.customer_total_amt = kk
            edit_items1.save()
            return redirect('admin_view_list')
        return render(request,'admin/admin_edit_items.html',{'Adm':Adm,'get_items':get_items,'cust':view_customer,'cat':cat})
    else:
            return redirect('/')

#Delete Items
def admin_delete_items(request,id):
    cat = admin_decor_items.objects.get(id=id)
    cat.delete()
    return redirect('admin_view_list')

#Add Decor Sub Items Ajax
def admin_ajax_add_subitem(request):
    if 'A_id' in request.session:
        if request.session.has_key('A_id'):
            A_id = request.session['A_id']
        else:
            return redirect('/')
        
        desig = login_register.objects.get(id=A_id)
        
        if request.method=='POST':
            Add_sitems = admin_decor_subitems()
            Add_sitems.item_category_id = request.POST.get('mscat')
            Add_sitems.item_id = request.POST.get('mitem')
            Add_sitems.subitem = request.POST.get('sitem')
            sqty = request.POST.get('sqty')
            sprice = request.POST.get('sprice')
            Add_sitems.customer_id = request.POST.get('cid')
            adv = request.POST.get('cadv')
            Add_sitems.branch_id = desig.branch.id
            Add_sitems.department_id = desig.department.id
            Add_sitems.designation_id = desig.designation.id
            Add_sitems.admin_id = A_id

            if not sqty:
                Add_sitems.sitem_qty = 1
                Add_sitems.sitem_qty_status = 'nill'
            else:
                Add_sitems.sitem_qty = int(sqty)
                Add_sitems.sitem_qty_status = 'data'

            if not sprice:
                Add_sitems.sitem_price = 1
                Add_sitems.sitem_price_status = 'nill'
            else:
                Add_sitems.sitem_price = int(sprice)
                Add_sitems.sitem_price_status = 'data'

            if Add_sitems.sitem_price_status == 'data' and Add_sitems.sitem_qty_status == 'data':
                Add_sitems.sitem_total = int(Add_sitems.sitem_qty) * int(Add_sitems.sitem_price)
            elif Add_sitems.sitem_price_status == 'data' and Add_sitems.sitem_qty_status == 'nill':
                Add_sitems.sitem_total = 1 * int(Add_sitems.sitem_price)
            elif Add_sitems.sitem_price_status == 'nill' and Add_sitems.sitem_qty_status == 'data':
                Add_sitems.sitem_total = 0
            elif Add_sitems.sitem_price_status == 'nill' and Add_sitems.sitem_qty_status == 'nill':
                Add_sitems.sitem_total = 0
            else:
                return

            total = admin_decor_subitems.objects.filter(
                customer_id=Add_sitems.customer_id
            )
            mtotal = admin_decor_items.objects.filter(
                customer_id=Add_sitems.customer_id
            )   
            n=0
            for i in total:
                n+=int(i.sitem_total or 0)
            s=Add_sitems.sitem_total+n   
            vv=0 
            for l in mtotal:
                vv+=int(l.item_total or 0)
            
            kk=vv+s
            
            Add_sitems.sitem_final_amount = s
            Add_sitems.sitem_payable_amount = s - int(adv)
            # Add_items.item_final_amount = a - int(advance)



            Add_sitems.save()

            Add_sitems1 = admin_Customer.objects.get(id=Add_sitems.customer_id)
            Add_sitems1.customer_total_amt = kk
            Add_sitems1.customer_payable_amt = kk - int(adv)
            Add_sitems1.save()
            return render(request,'admin/admin_document.html')
        else:
            return JsonResponse({'success': False, 'message': 'Invalid request method'})
    else:
            return redirect('/')

#Edit Decor SubItems
def admin_edit_subitems(request,id):
    if 'A_id' in request.session:
        if request.session.has_key('A_id'):
            A_id = request.session['A_id']
        else:
            return redirect('/')
        Adm=login_register.objects.get(id= A_id)
        desig = login_register.objects.get(id=A_id)
        view_customer = admin_Customer.objects.filter(admin_id=A_id)
        cat = admin_Category.objects.filter(admin_id=A_id)
        get_sitems = admin_decor_subitems.objects.get(id=id)
        
        get_items = admin_decor_items.objects.filter(admin_id=A_id,customer_id=get_sitems.customer_id)
        if request.method=='POST':
            edit_sitems = admin_decor_subitems.objects.get(id=id)
            edit_sitems.item_category_id = request.POST.get('mscat')
            edit_sitems.item_id = request.POST.get('mitem')
            edit_sitems.subitem = request.POST.get('sitem')
            sqty = request.POST.get('sqty')
            sprice = request.POST.get('sprice')
            adv = request.POST.get('cadv')

            if not sqty:
                edit_sitems.sitem_qty = 1
                edit_sitems.sitem_qty_status = 'nill'
            else:
                edit_sitems.sitem_qty = int(sqty)
                edit_sitems.sitem_qty_status = 'data'

            if not sprice:
                edit_sitems.sitem_price = 1
                edit_sitems.sitem_price_status = 'nill'
            else:
                edit_sitems.sitem_price = int(sprice)
                edit_sitems.sitem_price_status = 'data'

            if edit_sitems.sitem_price_status == 'data' and edit_sitems.sitem_qty_status == 'data':
                edit_sitems.sitem_total = int(edit_sitems.sitem_qty) * int(edit_sitems.sitem_price)
            elif edit_sitems.sitem_price_status == 'data' and edit_sitems.sitem_qty_status == 'nill':
                edit_sitems.sitem_total = 1 * int(edit_sitems.sitem_price)
            elif edit_sitems.sitem_price_status == 'nill' and edit_sitems.sitem_qty_status == 'data':
                edit_sitems.sitem_total = 0
            elif edit_sitems.sitem_price_status == 'nill' and edit_sitems.sitem_qty_status == 'nill':
                edit_sitems.sitem_total = 0

            total = admin_decor_subitems.objects.filter(
                customer_id=edit_sitems.customer_id
            )
            mtotal = admin_decor_items.objects.filter(
                customer_id=edit_sitems.customer_id
            )   
            n=0
            for i in total:
                n+=int(i.sitem_total or 0)
            s=edit_sitems.sitem_total+n   
            vv=0 
            for l in mtotal:
                vv+=int(l.item_total or 0)
            
            kk=vv+s
            
            edit_sitems.sitem_final_amount = s
            edit_sitems.sitem_payable_amount = s - int(adv)
            # Add_items.item_final_amount = a - int(advance)



            edit_sitems.save()

            edit_sitems1 = admin_Customer.objects.get(id=edit_sitems.customer_id)
            edit_sitems1.customer_total_amt = kk
            edit_sitems1.customer_payable_amt = kk - int(adv)
            edit_sitems1.save()
            return redirect('admin_view_list')
        return render(request,'admin/admin_edit_subitems.html',{'Adm':Adm,'get_items':get_items,'get_sitems':get_sitems,'cust':view_customer,'cat':cat})
    else:
            return redirect('/')

#Delete Items
def admin_delete_subitems(request,id):
    cat = admin_decor_subitems.objects.get(id=id)
    cat.delete()
    return redirect('admin_view_list')

#Gallery
def admin_add_gallery(request,id):
    if 'A_id' in request.session:
        if request.session.has_key('A_id'):
            A_id = request.session['A_id']
        else:
            return redirect('/')
        Adm=login_register.objects.get(id= A_id)
        desig = login_register.objects.get(id=A_id)
        view_customer = admin_Customer.objects.get(id=id)
        gal = admin_gallery.objects.filter(customer_id=id,admin_id=A_id)
        return render(request,'admin/admin_add_gallery.html',{'cust':view_customer,'Adm':Adm,'gal':gal})
        
    else:
            return redirect('/')

#Add Gallery Ajax
def admin_ajax_add_gallery_save(request):
    if 'A_id' in request.session:
        if request.session.has_key('A_id'):
            A_id = request.session['A_id']
        else:
            return redirect('/')
        
        desig = login_register.objects.get(id=A_id)
        if request.method=='POST':
            Add_gallery = admin_gallery()
            Add_gallery.img_name = request.POST.get('img_name')
            Add_gallery.gallery_img = request.FILES.get('img')
            Add_gallery.customer_id = request.POST.get('cid')
            Add_gallery.branch_id = desig.branch.id
            Add_gallery.department_id = desig.department.id
            Add_gallery.designation_id = desig.designation.id
            Add_gallery.admin_id = A_id
            
            Add_gallery.save()

            return render(request,'admin/admin_add_gallery.html')
        else:
            return JsonResponse({'success': False, 'message': 'Invalid request method'})
    else:
            return redirect('/')

#Edit Gallery
def admin_edit_gallery(request,id):
    if 'A_id' in request.session:
        if request.session.has_key('A_id'):
            A_id = request.session['A_id']
        else:
            return redirect('/')
        Adm=login_register.objects.get(id= A_id)
        desig = login_register.objects.get(id=A_id)
        gal = admin_gallery.objects.get(id=id)
        if request.method=='POST':
            edit_gallery = admin_gallery.objects.get(id=id)
            edit_gallery.img_name = request.POST.get('img_name')
            edit_gallery.gallery_img = request.FILES.get('img')
            
            edit_gallery.save()
            return redirect('admin_view_list')
        return render(request,'admin/admin_edit_gallery.html',{'Adm':Adm,'gal':gal})
        
    else:
            return redirect('/')



#Delete Gallery Ajax
@require_POST
def admin_ajax_delete_gallery(request):
    gallery_id = request.POST.get("id")

    try:
        gallery = admin_gallery.objects.get(id=gallery_id)

        # Delete uploaded image from media storage
        if gallery.gallery_img:
            gallery.gallery_img.delete(save=False)

        gallery.delete()

        return JsonResponse({
            "status": "success",
            "message": "Gallery deleted successfully"
        })

    except admin_gallery.DoesNotExist:
        return JsonResponse({
            "status": "error",
            "message": "Gallery not found"
        }, status=404)